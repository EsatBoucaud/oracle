import React, { useState, useMemo } from 'react';
import { Sidebar } from './components/Sidebar';
import { MainContent } from './components/MainContent';
import { EventModal } from './components/EventModal';
import { SettingsModal } from './components/SettingsModal';
import { mockEvents, CalendarEvent, CALENDARS } from './data/mockData';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';

export type ViewMode = 'Day' | 'Week' | 'Month';

function AppContent() {
  const { backgroundImage } = useTheme();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [events, setEvents] = useState<CalendarEvent[]>(mockEvents);
  const [view, setView] = useState<ViewMode>('Week');
  const [selectedCalendars, setSelectedCalendars] = useState<Set<string>>(
    new Set(CALENDARS.map(c => c.id))
  );
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredEvents = useMemo(() => {
    return events.filter(e => {
      const matchesCalendar = selectedCalendars.has(e.calendarId);
      const matchesSearch = e.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            (e.description && e.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
                            (e.location && e.location.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCalendar && matchesSearch;
    });
  }, [events, selectedCalendars, searchQuery]);

  const handleToggleCalendar = (id: string) => {
    const next = new Set(selectedCalendars);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedCalendars(next);
  };

  const handleAddEvent = () => {
    setSelectedEvent(null);
    setSelectedTime(null);
    setIsModalOpen(true);
  };

  const handleEventClick = (event: CalendarEvent) => {
    setSelectedEvent(event);
    setSelectedTime(null);
    setIsModalOpen(true);
  };

  const handleGridClick = (date: Date, time: string) => {
    setCurrentDate(date);
    setSelectedEvent(null);
    setSelectedTime(time);
    setIsModalOpen(true);
  };

  const handleSaveEvent = (eventData: Omit<CalendarEvent, 'id'> | CalendarEvent) => {
    if ('id' in eventData && eventData.id) {
      setEvents(events.map(e => e.id === eventData.id ? eventData as CalendarEvent : e));
    } else {
      const newEvent: CalendarEvent = {
        ...eventData,
        id: Math.random().toString(36).substr(2, 9),
      };
      setEvents([...events, newEvent]);
    }
  };

  const handleDeleteEvent = (id: string) => {
    setEvents(events.filter(e => e.id !== id));
  };

  return (
    <div className="flex h-screen w-full bg-zinc-50 dark:bg-zinc-950 overflow-hidden font-sans text-zinc-900 dark:text-zinc-100 relative">
      {backgroundImage && (
        <div 
          className="absolute inset-0 z-0 opacity-20 dark:opacity-10 pointer-events-none"
          style={{
            backgroundImage: `url(${backgroundImage})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
      )}
      <div className="flex h-full w-full z-10 relative">
        <Sidebar 
          currentDate={currentDate} 
          onDateChange={setCurrentDate} 
          events={filteredEvents}
          onAddEvent={handleAddEvent}
          onEventClick={handleEventClick}
          selectedCalendars={selectedCalendars}
          onToggleCalendar={handleToggleCalendar}
          onOpenSettings={() => setIsSettingsOpen(true)}
        />
        <MainContent 
          currentDate={currentDate} 
          onDateChange={setCurrentDate} 
          events={filteredEvents}
          onEventClick={handleEventClick}
          onGridClick={handleGridClick}
          view={view}
          onViewChange={setView}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />
      </div>
      <EventModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveEvent}
        onDelete={handleDeleteEvent}
        event={selectedEvent}
        selectedDate={currentDate}
        selectedTime={selectedTime}
      />
      <SettingsModal 
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}
