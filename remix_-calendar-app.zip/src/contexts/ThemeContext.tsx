import React, { createContext, useContext, useState, useEffect } from 'react';

type ThemeMode = 'light' | 'dark';
type AccentColor = 'blue' | 'purple' | 'emerald' | 'rose' | 'amber';

interface ThemeContextType {
  mode: ThemeMode;
  setMode: (mode: ThemeMode) => void;
  accent: AccentColor;
  setAccent: (accent: AccentColor) => void;
  backgroundImage: string | null;
  setBackgroundImage: (image: string | null) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [mode, setMode] = useState<ThemeMode>('light');
  const [accent, setAccent] = useState<AccentColor>('blue');
  const [backgroundImage, setBackgroundImage] = useState<string | null>(null);

  useEffect(() => {
    if (mode === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [mode]);

  useEffect(() => {
    const colors = {
      blue: { base: '#3b82f6', light: '#eff6ff', darkLight: '#1e3a8a', text: '#1d4ed8', darkText: '#93c5fd' },
      purple: { base: '#a855f7', light: '#faf5ff', darkLight: '#581c87', text: '#7e22ce', darkText: '#d8b4fe' },
      emerald: { base: '#10b981', light: '#ecfdf5', darkLight: '#064e3b', text: '#047857', darkText: '#6ee7b7' },
      rose: { base: '#f43f5e', light: '#fff1f2', darkLight: '#881337', text: '#be123c', darkText: '#fda4af' },
      amber: { base: '#f59e0b', light: '#fffbeb', darkLight: '#78350f', text: '#b45309', darkText: '#fcd34d' },
    };
    const c = colors[accent];
    const root = document.documentElement;
    root.style.setProperty('--color-accent', c.base);
    root.style.setProperty('--color-accent-light', mode === 'dark' ? c.darkLight : c.light);
    root.style.setProperty('--color-accent-text', mode === 'dark' ? c.darkText : c.text);
  }, [accent, mode]);

  return (
    <ThemeContext.Provider value={{ mode, setMode, accent, setAccent, backgroundImage, setBackgroundImage }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme must be used within ThemeProvider');
  return context;
}
